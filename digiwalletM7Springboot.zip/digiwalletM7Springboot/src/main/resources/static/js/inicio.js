$('#btn-pagos').click(function () {
    swal("Pago OnLine", "Servicio de pago online por implementar");
  })