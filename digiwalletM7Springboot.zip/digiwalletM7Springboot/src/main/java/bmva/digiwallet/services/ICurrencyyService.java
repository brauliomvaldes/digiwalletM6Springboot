package bmva.digiwallet.services;

import java.util.List;

import bmva.digiwallet.models.Currencyy;

public interface ICurrencyyService {

	List<Currencyy> findAll();
	
}
